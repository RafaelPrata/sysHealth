/* All free solid fontawesome icons -> https://fontawesome.com/icons?d=gallery&s=regular&m=free */

import { faBell } from '@fortawesome/free-regular-svg-icons';

export const fontAwesomeRegularIcons = {
    faBell,
};
